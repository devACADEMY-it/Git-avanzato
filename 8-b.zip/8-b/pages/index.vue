<template>
  <div class="page">
    <BlogCard slug="a" title="Magnam est dolores A" date="10/02/2020">
      Tempore ipsum eos id itaque doloremque officiis. Consequatur adipisci
      commodi perferendis est eos. Aspernatur ab vel. Placeat in similique
      accusantium ipsa.
    </BlogCard>

    <BlogCard slug="b" title="Magnam est dolores B" date="10/02/2020">
      Tempore ipsum eos id itaque doloremque officiis. Consequatur adipisci
      commodi perferendis est eos. Aspernatur ab vel. Placeat in similique
      accusantium ipsa.
    </BlogCard>

    <BlogCard slug="c" title="Magnam est dolores C" date="10/02/2020">
      Tempore ipsum eos id itaque doloremque officiis. Consequatur adipisci
      commodi perferendis est eos. Aspernatur ab vel. Placeat in similique
      accusantium ipsa.
    </BlogCard>

    <BlogCard slug="d" title="Magnam est dolores D" date="10/02/2020">
      Tempore ipsum eos id itaque doloremque officiis. Consequatur adipisci
      commodi perferendis est eos. Aspernatur ab vel. Placeat in similique
      accusantium ipsa.
    </BlogCard>
  </div>
</template>

<script>
import BlogCard from "@/components/BlogCard"

export default {
  components: {
    BlogCard
  }
}
</script>
