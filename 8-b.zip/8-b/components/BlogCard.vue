<template>
  <div class="card block">
    <header class="card-header">
      <p class="card-header-title">
        <nuxt-link :to="`/posts/${slug}`">{{ title }}</nuxt-link>
      </p>
    </header>
    <div class="card-content">
      <div class="content">
        <slot />
      </div>
    </div>
    <footer class="card-footer has-text-right is-block">{{ date }}</footer>
  </div>
</template>

<script>
export default {
  name: "BlogCard",
  props: {
    title: { type: String, required: true },
    date: { type: String, required: true },
    slug: { type: String, required: true }
  }
}
</script>

<style></style>
