<template>
  <article>
    <h1 class="title">{{ title }}</h1>
    <h2 class="subtitle">{{ date }}</h2>
    <main class="content">
      <slot />
    </main>
  </article>
</template>

<script>
export default {
  name: "BlogArticle",
  props: {
    title: { type: String, required: true },
    date: { type: String, required: true }
  }
}
</script>

<style></style>
