<template>
  <div class="page">
    <BlogArticle title="Magnam est dolores D" date="10/02/2020">
      Tempore ipsum eos id itaque doloremque officiis. Consequatur adipisci
      commodi perferendis est eos. Aspernatur ab vel. Placeat in similique
      accusantium ipsa.
    </BlogArticle>
  </div>
</template>

<script>
import BlogArticle from "@/components/BlogArticle"

export default {
  components: {
    BlogArticle
  }
}
</script>

<style></style>
